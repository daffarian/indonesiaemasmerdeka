'use server'

import requestIp from 'request-ip'

export default async function countVisitors(){
  
}