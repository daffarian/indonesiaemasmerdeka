export interface CardArticleTypes {
  id: number;
  image_url: string;
  date: Date;
  category: string;
  title: string;
  description: string;
  slug: string;
  className?: string;
}
