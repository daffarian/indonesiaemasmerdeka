import Csr from "@/components/common/Csr";
export default function Page() {
  return <Csr className="pt-20 lg:pt-20"/>;
}
