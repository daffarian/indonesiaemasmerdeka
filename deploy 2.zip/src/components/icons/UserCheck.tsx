import { UserCheck } from "lucide-react";

export default function UserCheckIcon({ className }: { className?: string }) {
  return <UserCheck className={className} />;
}
