import { Send } from "lucide-react";

export default function SendIcon({ className }: { className?: string }) {
  return <Send className={className} />;
}
