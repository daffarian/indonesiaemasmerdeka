import { Flower2 } from "lucide-react";

export default function FlowerIcon({ className }: { className?: string }) {
  return <Flower2 className={className} />;
}
