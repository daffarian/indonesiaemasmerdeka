import { Target } from "lucide-react";

export default function TargetIcon({ className }: { className?: string }) {
  return <Target className={className} />;
}
