import { CircleHelp } from "lucide-react";

export default function CircleHelpIcon({ className }: { className?: string }) {
  return <CircleHelp className={className} />;
}
