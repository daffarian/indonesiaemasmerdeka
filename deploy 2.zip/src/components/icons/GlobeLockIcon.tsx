import { GlobeLock } from "lucide-react";

export default function GlobeLockIcon({ className }: { className?: string }) {
  return <GlobeLock className={className} />;
}
