import { Cross } from "lucide-react";

export default function CrossIcon({ className }: { className?: string }) {
  return <Cross className={className} />;
}
