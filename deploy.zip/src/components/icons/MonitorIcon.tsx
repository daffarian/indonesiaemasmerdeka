import { Monitor } from "lucide-react";

export default function MonitorIcon({ className }: { className?: string }) {
  return <Monitor className={className} />;
}
